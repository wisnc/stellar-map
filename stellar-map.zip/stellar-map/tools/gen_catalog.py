#!/usr/bin/env python3
"""
gen_catalog.py  -  build flash headers for the Cardputer star-map firmware.

Emits:
  star_catalog.h   J2000 unit vectors + magnitude + B-V*1000 + distance (LY)
  star_names.h     label / spectral type / constellation per star
  constellations.h constellation line segments as catalog-index pairs
  messier.h        110 Messier deep-sky objects (vector, mag, id, name, type, con)

Run:  python3 gen_catalog.py [mag_limit]   (default 6.5)
"""
import csv, io, math, re, sys, urllib.request, os

MAG_LIMIT = float(sys.argv[1]) if len(sys.argv) > 1 else 6.5
OUT = os.path.join(os.path.dirname(__file__), "..", "src", "data")
PC_TO_LY = 3.2615638

SPLIT_CONST = {"Ser": ("Caput", "Cauda")}
SEARCH_ALIAS_CONST = {"Ser1": "Serpens Caput", "Ser2": "Serpens Cauda"}
_GREEK = ("Alp", "Bet", "Gam", "Del", "Eps", "Zet", "Eta", "The", "Iot", "Kap",
          "Lam", "Mu", "Nu", "Xi", "Omi", "Pi", "Rho", "Sig", "Tau", "Ups",
          "Phi", "Chi", "Psi", "Ome")
SYSTEM_LABELS = {"Rigil Kentaurus": "Alpha Centauri"}
COINCIDENT_ARCSEC = 60.0
FOV_MIN_DEG = 6
FOV_MAX_DEG = 80
FRAME_MARGIN = 1.15

_BAYER = re.compile(r"^[A-Za-z]{2,3}\s+[A-Z][A-Za-z]{2}$")
_FLAM = re.compile(r"^\d+\s+[A-Z][A-Za-z]{2}$")

def is_proper_name(label):
    if not label or label.startswith("HIP") or label[0].isdigit():
        return False
    if _BAYER.match(label) or _FLAM.match(label):
        return False
    if any(c.isdigit() for c in label) and any(label.startswith(g) for g in _GREEK):
        return False
    return True

def _unit(v):
    n = math.sqrt(sum(c * c for c in v))
    return tuple(c / n for c in v)

def _sep_deg(a, b):
    d = sum(a[k] * b[k] for k in range(3))
    return math.degrees(math.acos(max(-1.0, min(1.0, d))))

def _centroid(vs):
    v = [sum(p[k] for p in vs) / len(vs) for k in range(3)]
    return _unit(v)

def _split_two(ids, pos):
    a0 = max(ids, key=lambda j: _sep_deg(pos[ids[0]], pos[j]))
    b0 = max(ids, key=lambda j: _sep_deg(pos[a0], pos[j]))
    A = [i for i in ids if _sep_deg(pos[i], pos[a0]) <= _sep_deg(pos[i], pos[b0])]
    B = [i for i in ids if i not in A]
    ra = lambda g: sum(math.atan2(pos[i][1], pos[i][0]) % (2 * math.pi) for i in g) / len(g)
    return (A, B) if ra(A) < ra(B) else (B, A)

def con_keys(segs, con_of_star, pos):
    key = dict()
    ids_by_con = {}
    for a, b in segs:
        for i in (a, b):
            ids_by_con.setdefault(con_of_star[i], set()).add(i)
    names = {}
    for c, ids in ids_by_con.items():
        if c in SPLIT_CONST:
            g1, g2 = _split_two(sorted(ids), pos)
            for i in g1: key[i] = c + "1"
            for i in g2: key[i] = c + "2"
            names[c + "1"], names[c + "2"] = SPLIT_CONST[c]
        else:
            for i in ids: key[i] = c
            names[c] = IAU_NAMES[c]
    return key, names


IAU_NAMES = {
    "And": "Andromeda", "Ant": "Antlia", "Aps": "Apus", "Aqr": "Aquarius",
    "Aql": "Aquila", "Ara": "Ara", "Ari": "Aries", "Aur": "Auriga",
    "Boo": "Bootes", "Cae": "Caelum", "Cam": "Camelopardalis", "Cnc": "Cancer",
    "CVn": "Canes Venatici", "CMa": "Canis Major", "CMi": "Canis Minor",
    "Cap": "Capricornus", "Car": "Carina", "Cas": "Cassiopeia", "Cen": "Centaurus",
    "Cep": "Cepheus", "Cet": "Cetus", "Cha": "Chamaeleon", "Cir": "Circinus",
    "Col": "Columba", "Com": "Coma Berenices", "CrA": "Corona Australis",
    "CrB": "Corona Borealis", "Crv": "Corvus", "Crt": "Crater", "Cru": "Crux",
    "Cyg": "Cygnus", "Del": "Delphinus", "Dor": "Dorado", "Dra": "Draco",
    "Equ": "Equuleus", "Eri": "Eridanus", "For": "Fornax", "Gem": "Gemini",
    "Gru": "Grus", "Her": "Hercules", "Hor": "Horologium", "Hya": "Hydra",
    "Hyi": "Hydrus", "Ind": "Indus", "Lac": "Lacerta", "Leo": "Leo",
    "LMi": "Leo Minor", "Lep": "Lepus", "Lib": "Libra", "Lup": "Lupus",
    "Lyn": "Lynx", "Lyr": "Lyra", "Men": "Mensa", "Mic": "Microscopium",
    "Mon": "Monoceros", "Mus": "Musca", "Nor": "Norma", "Oct": "Octans",
    "Oph": "Ophiuchus", "Ori": "Orion", "Pav": "Pavo", "Peg": "Pegasus",
    "Per": "Perseus", "Phe": "Phoenix", "Pic": "Pictor", "Psc": "Pisces",
    "PsA": "Piscis Austrinus", "Pup": "Puppis", "Pyx": "Pyxis", "Ret": "Reticulum",
    "Sge": "Sagitta", "Sgr": "Sagittarius", "Sco": "Scorpius", "Scl": "Sculptor",
    "Sct": "Scutum", "Ser": "Serpens", "Sex": "Sextans", "Tau": "Taurus",
    "Tel": "Telescopium", "Tri": "Triangulum", "TrA": "Triangulum Australe",
    "Tuc": "Tucana", "UMa": "Ursa Major", "UMi": "Ursa Minor", "Vel": "Vela",
    "Vir": "Virgo", "Vol": "Volans", "Vul": "Vulpecula",
}

HYG_URLS = [
    "https://raw.githubusercontent.com/astronexus/HYG-Database/main/hyg/CURRENT/hygdata_v41.csv",
    "https://raw.githubusercontent.com/astronexus/HYG-Database/master/hyg/CURRENT/hygdata_v41.csv",
    "https://raw.githubusercontent.com/astronexus/HYG-Database/master/hygdata_v3.csv",
]
FAB_URLS = [
    "https://raw.githubusercontent.com/Stellarium/stellarium/v0.21.0/skycultures/western/constellationship.fab",
    "https://raw.githubusercontent.com/Stellarium/stellarium/v0.20.0/skycultures/western/constellationship.fab",
]
NGC_URLS = [
    "https://raw.githubusercontent.com/mattiaverga/OpenNGC/master/database_files/NGC.csv",
    "https://raw.githubusercontent.com/mattiaverga/OpenNGC/master/NGC.csv",
    "https://raw.githubusercontent.com/mattiaverga/OpenNGC/main/database_files/NGC.csv",
]
NGC_ADD_URLS = [
    "https://raw.githubusercontent.com/mattiaverga/OpenNGC/master/database_files/addendum/NGC_addendum.csv",
    "https://raw.githubusercontent.com/mattiaverga/OpenNGC/master/NGC_addendum.csv",
    "https://raw.githubusercontent.com/mattiaverga/OpenNGC/main/database_files/addendum/NGC_addendum.csv",
]

def fetch(urls, required=True):
    for u in urls:
        try:
            print("  trying", u)
            with urllib.request.urlopen(u, timeout=60) as r:
                data = r.read().decode("utf-8", "replace")
            print("  ok (%d bytes)" % len(data))
            return data, u
        except Exception as e:
            print("  fail:", e)
    if required:
        sys.exit("Could not fetch required resource.")
    return None, None

def cfloat(v):
    return ("%.6ff" % v)

def cstr(s):
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'

def hms_to_rad(s):
    p = s.split(":")
    h = float(p[0]) + float(p[1]) / 60.0 + float(p[2]) / 3600.0
    return h * 15.0 * math.pi / 180.0

def dms_to_rad(s):
    s = s.strip()
    sign = -1.0 if s[0] == "-" else 1.0
    s = s.lstrip("+-")
    p = s.split(":")
    d = float(p[0]) + float(p[1]) / 60.0 + float(p[2]) / 3600.0
    return sign * d * math.pi / 180.0

def build_stars():
    print("Fetching HYG database...")
    hyg, hyg_url = fetch(HYG_URLS)
    rows = list(csv.DictReader(io.StringIO(hyg)))
    stars, hip2idx = [], {}
    for r in rows:
        try:
            mag = float(r.get("mag", ""))
        except ValueError:
            continue
        try:
            vmx = float(r.get("var_max", "") or "")
            if vmx < mag:
                mag = vmx
        except ValueError:
            pass
        if mag > MAG_LIMIT:
            continue
        try:
            if float(r.get("dist", "1") or "1") == 0.0:
                continue
        except ValueError:
            pass
        rarad, decrad = r.get("rarad", ""), r.get("decrad", "")
        if rarad and decrad:
            ra, dec = float(rarad), float(decrad)
        else:
            ra = float(r["ra"]) * math.pi / 12.0
            dec = float(r["dec"]) * math.pi / 180.0
        x = math.cos(dec) * math.cos(ra)
        y = math.cos(dec) * math.sin(ra)
        z = math.sin(dec)
        try:
            ci = int(round(float(r.get("ci", "")) * 1000))
        except ValueError:
            ci = 0x7FFF
        try:
            dpc = float(r.get("dist", ""))
        except ValueError:
            dpc = -1.0
        ly = -1.0 if (dpc <= 0 or dpc >= 100000.0) else dpc * PC_TO_LY
        proper = (r.get("proper", "") or "").strip()
        bf = (r.get("bf", "") or "").strip()
        hip = (r.get("hip", "") or "").strip()
        label = proper if proper else (bf if bf else ("HIP " + hip if hip else ""))
        spect = (r.get("spect", "") or "").strip()[:8]
        con = (r.get("con", "") or "").strip()
        idx = len(stars)
        stars.append((x, y, z, mag, ci, ly, label, spect, con))
        if hip:
            try:
                hip2idx[int(hip)] = idx
            except ValueError:
                pass
    print("Stars kept (mag <= %.2f): %d" % (MAG_LIMIT, len(stars)))
    return stars, hip2idx, hyg_url

def build_segments(hip2idx):
    print("Fetching constellation lines...")
    fab, fab_url = fetch(FAB_URLS, required=False)
    segs, missing = [], 0
    if fab:
        for line in fab.splitlines():
            t = line.split()
            if len(t) < 3:
                continue
            try:
                n = int(t[1])
            except ValueError:
                continue
            hips = t[2:2 + 2 * n]
            for k in range(0, len(hips) - 1, 2):
                try:
                    a, b = int(hips[k]), int(hips[k + 1])
                except ValueError:
                    continue
                ia, ib = hip2idx.get(a), hip2idx.get(b)
                if ia is not None and ib is not None:
                    segs.append((ia, ib))
                else:
                    missing += 1
        print("Line segments: %d (skipped %d)" % (len(segs), missing))
    return segs, fab_url

def map_type(t):
    t = t.strip()
    if t in ("G", "GPair", "GTrpl", "GGroup"): return "Galaxy"
    if t == "OCl": return "Open Cluster"
    if t == "GCl": return "Globular"
    if t == "PN": return "Planetary Neb"
    if t == "SNR": return "Supernova Rem"
    if t in ("HII", "EmN", "Neb", "Cl+N", "RfN", "DrkN"): return "Nebula"
    if t in ("*", "**", "*Ass"): return "Star(s)"
    return t if t else "Object"

def build_messier():
    print("Fetching OpenNGC (Messier)...")
    main, ngc_url = fetch(NGC_URLS)
    add, _ = fetch(NGC_ADD_URLS, required=False)
    text = main + ("\n" + add if add else "")
    best = {}
    for r in csv.DictReader(io.StringIO(text), delimiter=";"):
        m = (r.get("M", "") or "").strip()
        if not m:
            continue
        try:
            num = int(m)
        except ValueError:
            continue
        if not (r.get("RA", "") or "").strip() or not (r.get("Dec", "") or "").strip():
            continue
        typ = (r.get("Type", "") or "").strip()
        if num in best and best[num][0] != "Dup" and typ == "Dup":
            continue
        best[num] = (typ, r)
    objs = []
    for num in sorted(best):
        typ, r = best[num]
        try:
            ra = hms_to_rad(r["RA"]); dec = dms_to_rad(r["Dec"])
        except Exception:
            continue
        x = math.cos(dec) * math.cos(ra)
        y = math.cos(dec) * math.sin(ra)
        z = math.sin(dec)
        try:
            mag = float(r.get("V-Mag", "") or "")
        except ValueError:
            try:
                mag = float(r.get("B-Mag", "") or "")
            except ValueError:
                mag = 99.0
        names = (r.get("Common names", "") or "").strip()
        name = names.split(",")[0].strip() if names else ""
        con = (r.get("Const", "") or "").strip()
        objs.append((x, y, z, mag, "M" + str(num), name, map_type(typ), con))

    have = {o[4] for o in objs}
    fallback = [

        (3.79000, 24.11667, 1.6,  "M45", "Pleiades",       "Open Cluster", "Tau"),
        (12.37014, 58.08306, 9.6, "M40", "Winnecke 4",     "Star(s)",      "UMa"),
        (15.10819, 55.76333, 9.9, "M102", "Spindle Galaxy","Galaxy",       "Dra"),
    ]
    for rah, decd, mag, mid, name, typ, con in fallback:
        if mid in have:
            continue
        ra = rah * 15.0 * math.pi / 180.0
        dec = decd * math.pi / 180.0
        objs.append((math.cos(dec) * math.cos(ra), math.cos(dec) * math.sin(ra),
                     math.sin(dec), mag, mid, name, typ, con))
    objs.sort(key=lambda o: int(o[4][1:]))
    print("Messier objects: %d" % len(objs))
    return objs, ngc_url

def emit_stars(stars, hyg_url):
    with open(os.path.join(OUT, "star_catalog.h"), "w") as f:
        f.write("// Generated by gen_catalog.py  (source: %s)\n" % hyg_url)
        f.write("// J2000 unit vectors, magnitude, B-V*1000 (0x7FFF=unknown), distance LY (-1=unknown).\n")
        f.write("#pragma once\n#include <cstdint>\n\n")
        f.write("constexpr int STAR_COUNT = %d;\n\n" % len(stars))
        f.write("const float star_xyz[STAR_COUNT][3] = {\n")
        for i in range(0, len(stars), 4):
            f.write("  " + " ".join("{%s,%s,%s}," % (cfloat(s[0]), cfloat(s[1]), cfloat(s[2]))
                                    for s in stars[i:i + 4]) + "\n")
        f.write("};\n\n")
        f.write("const float star_mag[STAR_COUNT] = {\n")
        for i in range(0, len(stars), 10):
            f.write("  " + " ".join(cfloat(s[3]) + "," for s in stars[i:i + 10]) + "\n")
        f.write("};\n\n")
        f.write("const int16_t star_ci[STAR_COUNT] = {\n")
        for i in range(0, len(stars), 12):
            f.write("  " + " ".join("%d," % s[4] for s in stars[i:i + 12]) + "\n")
        f.write("};\n\n")
        f.write("const float star_dist_ly[STAR_COUNT] = {\n")
        for i in range(0, len(stars), 10):
            f.write("  " + " ".join(cfloat(s[5]) + "," for s in stars[i:i + 10]) + "\n")
        f.write("};\n")

def emit_names(stars):
    with open(os.path.join(OUT, "star_names.h"), "w") as f:
        f.write("// Generated by gen_catalog.py\n#pragma once\n\n")
        for arr, k in (("star_label", 6), ("star_spect", 7), ("star_con", 8)):
            f.write("const char* const %s[STAR_COUNT] = {\n" % arr)
            for s in stars:
                f.write("  " + cstr(s[k]) + ",\n")
            f.write("};\n\n")

def emit_segments(segs, con_of_star, pos, fab_url):
    key, names = con_keys(segs, con_of_star, pos)
    keys = sorted(names)
    idx = {c: i for i, c in enumerate(keys)}
    ids_by_key = {}
    for a, b in segs:
        for i in (a, b):
            ids_by_key.setdefault(key[i], []).append(i)
    cxyz, cfov = [], []
    for c in keys:
        vs = [pos[i] for i in set(ids_by_key[c])]
        cen = _centroid(vs)
        spread = max(_sep_deg(cen, v) for v in vs)
        f = int(round(min(FOV_MAX_DEG, max(FOV_MIN_DEG, 2.0 * spread * FRAME_MARGIN))))
        cxyz.append(cen)
        cfov.append(f)
    with open(os.path.join(OUT, "constellations.h"), "w") as f:
        f.write("// Generated by gen_catalog.py  (source: %s)\n" % (fab_url or "none"))
        f.write("#pragma once\n#include <cstdint>\n\n")
        f.write("constexpr int CONST_SEG_COUNT = %d;\n" % len(segs))
        f.write("constexpr int CONST_COUNT = %d;\n\n" % len(keys))
        f.write("const uint16_t const_seg[CONST_SEG_COUNT > 0 ? CONST_SEG_COUNT : 1][2] = {\n")
        for i in range(0, len(segs), 8):
            f.write("  " + " ".join("{%d,%d}," % (a, b) for a, b in segs[i:i + 8]) + "\n")
        f.write("};\n\n")
        f.write("const uint8_t const_seg_con[CONST_SEG_COUNT > 0 ? CONST_SEG_COUNT : 1] = {\n")
        ids = [idx[key[a]] for a, b in segs]
        for i in range(0, len(ids), 16):
            f.write("  " + ",".join(str(v) for v in ids[i:i + 16]) + ",\n")
        f.write("};\n\n")
        f.write("const char* const const_name[CONST_COUNT] = {\n")
        for c in keys:
            f.write("  \"%s\",\n" % names[c])
        f.write("};\n\n")
        f.write("const float const_xyz[CONST_COUNT][3] = {\n")
        for v in cxyz:
            f.write("  {%s,%s,%s},\n" % (cfloat(v[0]), cfloat(v[1]), cfloat(v[2])))
        f.write("};\n\n")
        f.write("const uint8_t const_fov[CONST_COUNT] = {\n")
        for i in range(0, len(cfov), 16):
            f.write("  " + ",".join(str(v) for v in cfov[i:i + 16]) + ",\n")
        f.write("};\n")
    return keys, names, idx


def search_rank(label):
    if is_proper_name(label):
        return 0
    if label.startswith("HIP"):
        return 2
    return 1


def emit_search(stars, keys, names):
    ent = []
    for i, st in enumerate(stars):
        lb = st[6]
        if not lb:
            continue
        ent.append((search_rank(lb), lb, i, 0))
    for primary, alias in SYSTEM_LABELS.items():
        for i, st in enumerate(stars):
            if st[6] == primary:
                ent.append((0, alias, i, 0))
                break
    for j, c in enumerate(keys):
        ent.append((0, SEARCH_ALIAS_CONST.get(c, names[c]), j, 1))
    ent.sort(key=lambda e: (e[0], e[1].lower()))
    with open(os.path.join(OUT, "search_index.h"), "w") as f:
        f.write("// Generated by gen_catalog.py\n")
        f.write("#pragma once\n#include <cstdint>\n\n")
        f.write("constexpr int SEARCH_COUNT = %d;\n" % len(ent))
        f.write("constexpr uint8_t SEARCH_STAR = 0;\n")
        f.write("constexpr uint8_t SEARCH_CONST = 1;\n\n")
        f.write("const char* const search_name[SEARCH_COUNT] = {\n")
        for r, n, ref, k in ent:
            f.write("  \"%s\",\n" % n)
        f.write("};\n\n")
        f.write("const uint16_t search_ref[SEARCH_COUNT] = {\n")
        for i in range(0, len(ent), 16):
            f.write("  " + ",".join(str(e[2]) for e in ent[i:i + 16]) + ",\n")
        f.write("};\n\n")
        f.write("const uint8_t search_kind[SEARCH_COUNT] = {\n")
        for i in range(0, len(ent), 24):
            f.write("  " + ",".join(str(e[3]) for e in ent[i:i + 24]) + ",\n")
        f.write("};\n")
    return len(ent)


def emit_map_labels(stars):
    pos = [_unit((s[0], s[1], s[2])) for s in stars]
    lim = COINCIDENT_ARCSEC / 3600.0
    order = sorted(range(len(stars)), key=lambda i: pos[i][2])
    ov = {}
    for a in range(len(order)):
        i = order[a]
        for b in range(a + 1, len(order)):
            j = order[b]
            if pos[j][2] - pos[i][2] > math.radians(lim):
                break
            if _sep_deg(pos[i], pos[j]) > lim:
                continue
            if not (is_proper_name(stars[i][6]) and is_proper_name(stars[j][6])):
                continue
            hi, lo = (i, j) if stars[i][3] <= stars[j][3] else (j, i)
            ov[lo] = ""
            if stars[hi][6] in SYSTEM_LABELS:
                ov[hi] = SYSTEM_LABELS[stars[hi][6]]
    items = sorted(ov.items())
    with open(os.path.join(OUT, "map_labels.h"), "w") as f:
        f.write("// Generated by gen_catalog.py\n")
        f.write("#pragma once\n#include <cstdint>\n\n")
        f.write("constexpr int MAP_LABEL_COUNT = %d;\n\n" % len(items))
        f.write("const uint16_t map_label_idx[MAP_LABEL_COUNT > 0 ? MAP_LABEL_COUNT : 1] = {\n")
        f.write("  " + ",".join(str(k) for k, _ in items) + ("," if items else "0") + "\n};\n\n")
        f.write("const char* const map_label_txt[MAP_LABEL_COUNT > 0 ? MAP_LABEL_COUNT : 1] = {\n")
        for _, v in items:
            f.write("  \"%s\",\n" % v)
        if not items:
            f.write("  \"\"\n")
        f.write("};\n")
    return items


def emit_messier(objs, ngc_url):
    with open(os.path.join(OUT, "messier.h"), "w") as f:
        f.write("// Generated by gen_catalog.py  (source: %s, OpenNGC CC-BY-SA-4.0)\n" % ngc_url)
        f.write("#pragma once\n\n")
        f.write("constexpr int MESSIER_COUNT = %d;\n\n" % len(objs))
        f.write("const float messier_xyz[MESSIER_COUNT][3] = {\n")
        for o in objs:
            f.write("  {%s,%s,%s},\n" % (cfloat(o[0]), cfloat(o[1]), cfloat(o[2])))
        f.write("};\n\n")
        f.write("const float messier_mag[MESSIER_COUNT] = {\n")
        for i in range(0, len(objs), 10):
            f.write("  " + " ".join(cfloat(o[3]) + "," for o in objs[i:i + 10]) + "\n")
        f.write("};\n\n")
        for arr, k in (("messier_id", 4), ("messier_name", 5), ("messier_type", 6), ("messier_con", 7)):
            f.write("const char* const %s[MESSIER_COUNT] = {\n" % arr)
            for o in objs:
                f.write("  " + cstr(o[k]) + ",\n")
            f.write("};\n\n")

def main():
    os.makedirs(OUT, exist_ok=True)
    stars, hip2idx, hyg_url = build_stars()
    segs, fab_url = build_segments(hip2idx)
    objs, ngc_url = build_messier()
    emit_stars(stars, hyg_url)
    emit_names(stars)
    pos = [_unit((x[0], x[1], x[2])) for x in stars]
    keys, names, cidx = emit_segments(segs, [x[8] for x in stars], pos, fab_url)
    emit_search(stars, keys, names)
    emit_map_labels(stars)
    emit_messier(objs, ngc_url)
    print("Wrote headers to", os.path.abspath(OUT))

if __name__ == "__main__":
    main()
